package dev.mrkieha.mirage;

import dev.mrkieha.mirage.util.MirageTransform;
import dev.mrkieha.mirage.util.MirageValidation;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4590;
import net.minecraft.class_8104;
import net.minecraft.class_8113;

/**
 * Fluent factory for {@link MirageDisplay}.
 *
 * @since 1.0
 */
public class MirageBuilder {

    private final class_3218 world;

    private class_2680 blockState = class_2246.field_10340.method_9564();
    private class_1799 itemStack   = class_1799.field_8037;
    private class_2561 displayText      = null;
    private class_1299<? extends class_8113> entityType = class_1299.field_42460;

    private class_243 position                    = class_243.field_1353;
    private MirageTransform transform         = MirageTransform.identity();
    private int interpolationDuration         = 0;
    private float viewRange                   = 1.0f;
    private float shadowRadius                = 0.0f;
    private float shadowStrength              = 1.0f;
    private class_8113.class_8114 billboard = class_8113.class_8114.field_42406;
    private int glowColor                     = -1;
    private int brightnessBlock               = -1;
    private int brightnessSky                 = -1;

    private MirageBuilder(class_3218 world) {
        this.world = MirageValidation.requireNonNull(world, "world");
    }

    /**
     * Creates a builder for the given world.
     *
     * @param world the world
     * @return a new builder
     */
    public static MirageBuilder in(class_3218 world) {
        return new MirageBuilder(world);
    }

    /* ---------- Content ---------- */

    /**
     * Sets block content.
     *
     * @param state the block state
     * @return this
     */
    public MirageBuilder block(class_2680 state) {
        this.blockState = state;
        this.entityType = class_1299.field_42460;
        return this;
    }

    /**
     * Sets item content.
     *
     * @param stack the item stack
     * @return this
     */
    public MirageBuilder item(class_1799 stack) {
        this.itemStack = stack;
        this.entityType = class_1299.field_42456;
        return this;
    }

    /**
     * Sets text content.
     *
     * @param text the text
     * @return this
     */
    public MirageBuilder text(class_2561 text) {
        this.displayText = text;
        this.entityType = class_1299.field_42457;
        return this;
    }

    /* ---------- Position ---------- */

    /**
     * Sets position from coordinates.
     *
     * @param x world X
     * @param y world Y
     * @param z world Z
     * @return this
     */
    public MirageBuilder at(double x, double y, double z) {
        this.position = new class_243(x, y, z);
        return this;
    }

    /**
     * Sets position from a vector.
     *
     * @param pos the position
     * @return this
     */
    public MirageBuilder at(class_243 pos) {
        this.position = pos;
        return this;
    }

    /* ---------- Transform ---------- */

    /**
     * Sets the initial transform.
     *
     * @param transform the transform
     * @return this
     */
    public MirageBuilder transform(MirageTransform transform) {
        this.transform = MirageValidation.requireNonNull(transform, "transform");
        return this;
    }

    /**
     * Sets a raw vanilla transform.
     *
     * @param raw the vanilla transform
     * @return this
     */
    public MirageBuilder rawTransform(class_4590 raw) {
        this.transform = MirageTransform.fromVanilla(raw);
        return this;
    }

    /**
     * Sets uniform scale.
     *
     * @param uniform the scale factor
     * @return this
     */
    public MirageBuilder scale(float uniform) {
        this.transform.scale(uniform);
        return this;
    }

    /**
     * Sets non-uniform scale.
     *
     * @param x scale on X
     * @param y scale on Y
     * @param z scale on Z
     * @return this
     */
    public MirageBuilder scale(float x, float y, float z) {
        this.transform.scale(x, y, z);
        return this;
    }

    /**
     * Accumulates rotation on all axes.
     *
     * @param x degrees on X
     * @param y degrees on Y
     * @param z degrees on Z
     * @return this
     */
    public MirageBuilder rotate(float x, float y, float z) {
        this.transform.rotate(x, y, z);
        return this;
    }

    /**
     * Accumulates Y-axis rotation.
     *
     * @param degrees angle in degrees
     * @return this
     */
    public MirageBuilder rotateY(float degrees) {
        this.transform.rotateY(degrees);
        return this;
    }

    /* ---------- Interpolation ---------- */

    /**
     * Sets interpolation duration.
     *
     * @param ticks duration in ticks
     * @return this
     */
    public MirageBuilder interpolation(int ticks) {
        this.interpolationDuration = ticks;
        return this;
    }

    /* ---------- Visual ---------- */

    /**
     * Sets view range multiplier.
     *
     * @param range the multiplier
     * @return this
     */
    public MirageBuilder viewRange(float range) {
        this.viewRange = range;
        return this;
    }

    /**
     * Sets shadow parameters.
     *
     * @param radius   shadow radius
     * @param strength shadow strength
     * @return this
     */
    public MirageBuilder shadow(float radius, float strength) {
        this.shadowRadius   = radius;
        this.shadowStrength = strength;
        return this;
    }

    /** Disables shadow. */
    public MirageBuilder noShadow() {
        return shadow(0f, 0f);
    }

    /**
     * Sets billboard mode.
     *
     * @param mode the mode
     * @return this
     */
    public MirageBuilder billboard(class_8113.class_8114 mode) {
        this.billboard = mode;
        return this;
    }

    /**
     * Sets glow outline color.
     *
     * @param argb ARGB, or -1 to disable
     * @return this
     */
    public MirageBuilder glowColor(int argb) {
        this.glowColor = argb;
        return this;
    }

    /**
     * Toggles vanilla glowing.
     *
     * @param enabled true to enable
     * @return this
     */
    public MirageBuilder glow(boolean enabled) {
        this.glowColor = enabled ? 0xFFFFFFFF : -1;
        return this;
    }

    /**
     * Sets brightness override.
     *
     * @param block block light, 0–15
     * @param sky   sky light, 0–15
     * @return this
     */
    public MirageBuilder brightness(int block, int sky) {
        this.brightnessBlock = block;
        this.brightnessSky   = sky;
        return this;
    }

    /** Sets full brightness (15/15). */
    public MirageBuilder fullBright() {
        return brightness(15, 15);
    }

    /* ---------- Clone ---------- */

    /**
     * Copies settings from an existing display.
     * Position and UUID are not copied.
     *
     * @param source the source display
     * @return this
     */
    public MirageBuilder cloneFrom(MirageDisplay source) {
        MirageValidation.requireNonNull(source, "source");
        class_8113 e = source.getEntity();
        this.interpolationDuration = e.method_48866();
        this.viewRange = e.method_48869();
        this.shadowRadius = e.method_48870();
        this.shadowStrength = e.method_48871();
        this.billboard = e.method_48864();
        int packed = e.method_48865();
        if (packed != -1) {
            this.brightness(class_8104.method_48764(packed).comp_1240(), class_8104.method_48764(packed).comp_1241());
        }
        this.glowColor = e.method_48876();
        this.transform = MirageTransform.fromVanilla(e.method_48845(e.method_5841()));

        if (e instanceof class_8113.class_8115) {
            this.block(((class_8113.class_8115) e).method_48884());
        } else if (e instanceof class_8113.class_8122) {
            this.item(((class_8113.class_8122) e).method_48900());
        } else if (e instanceof class_8113.class_8123) {
            this.text(((class_8113.class_8123) e).method_48915());
        }
        return this;
    }

    /* ---------- Build ---------- */

    /**
     * Builds the display without spawning.
     *
     * @return the configured display
     */
    public MirageDisplay build() {
        class_8113 entity;
        if (entityType == class_1299.field_42456) {
            entity = new class_8113.class_8122(class_1299.field_42456, world);
            ((class_8113.class_8122) entity).method_48897(itemStack);
        } else if (entityType == class_1299.field_42457) {
            entity = new class_8113.class_8123(class_1299.field_42457, world);
            if (displayText != null) {
                ((class_8113.class_8123) entity).method_48911(displayText);
            }
        } else {
            entity = new class_8113.class_8115(class_1299.field_42460, world);
            ((class_8113.class_8115) entity).method_48883(blockState);
        }

        entity.method_5814(position.field_1352, position.field_1351, position.field_1350);
        entity.method_48849(transform.build());
        entity.method_48853(interpolationDuration);
        entity.method_48861(viewRange);
        entity.method_48862(shadowRadius);
        entity.method_48872(shadowStrength);
        entity.method_48847(billboard);

        if (glowColor != -1) {
            entity.method_48858(glowColor);
        }

        if (brightnessBlock >= 0 && brightnessSky >= 0) {
            entity.method_48846(new class_8104(brightnessBlock, brightnessSky));
        }

        return new MirageDisplay(entity, world);
    }

    /**
     * Builds and spawns the display.
     *
     * @return the spawned display
     */
    public MirageDisplay buildAndSpawn() {
        MirageDisplay display = build();
        display.spawn();
        return display;
    }
}