package dev.mrkieha.mirage;

import dev.mrkieha.mirage.util.MirageMath;
import dev.mrkieha.mirage.util.MirageTransform;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_243;

/**
 * Group of displays that preserves relative offsets from a center point.
 *
 * @since 1.0
 */
public class MirageGroup {

    private final List<MirageDisplay> displays = new ArrayList<>();
    private final Map<MirageDisplay, class_243> offsets = new HashMap<>();
    private class_243 center = class_243.field_1353;

    /**
     * Sets the group center.
     *
     * @param center the center
     * @return this
     */
    public MirageGroup center(class_243 center) {
        this.center = center;
        return this;
    }

    /**
     * Adds a display, snapping its current offset from center.
     *
     * @param display the display
     * @return this
     */
    public MirageGroup add(MirageDisplay display) {
        if (!displays.contains(display)) {
            displays.add(display);
            offsets.put(display, display.getPos().method_1020(center));
        }
        return this;
    }

    /**
     * Adds a display with an explicit offset.
     *
     * @param display the display
     * @param offset  the offset from center
     * @return this
     */
    public MirageGroup add(MirageDisplay display, class_243 offset) {
        if (!displays.contains(display)) {
            displays.add(display);
            offsets.put(display, offset);
        }
        return this;
    }

    /**
     * Bulk-adds displays.
     *
     * @param displays the collection
     * @return this
     */
    public MirageGroup addAll(Collection<MirageDisplay> displays) {
        displays.forEach(this::add);
        return this;
    }

    /**
     * Moves the group center.
     *
     * @param newCenter the target center
     */
    public void moveTo(class_243 newCenter) {
        for (MirageDisplay d : displays) {
            class_243 offset = offsets.getOrDefault(d, class_243.field_1353);
            d.moveTo(newCenter.method_1019(offset));
        }
        this.center = newCenter;
    }

    /**
     * Moves the group center to coordinates.
     *
     * @param x world X
     * @param y world Y
     * @param z world Z
     */
    public void moveTo(double x, double y, double z) {
        moveTo(new class_243(x, y, z));
    }

    /**
     * Moves the group with interpolation.
     *
     * @param newCenter     the target center
     * @param durationTicks interpolation duration
     */
    public void interpolateTo(class_243 newCenter, int durationTicks) {
        for (MirageDisplay d : displays) {
            class_243 offset = offsets.getOrDefault(d, class_243.field_1353);
            d.moveTo(newCenter.method_1019(offset), durationTicks);
        }
        this.center = newCenter;
    }

    /**
     * Applies a transform to all members instantly.
     *
     * @param transform the transform
     */
    public void transform(MirageTransform transform) {
        displays.forEach(d -> d.transform(transform).startInterpolation(0));
    }

    /**
     * Applies a transform with interpolation.
     *
     * @param transform     the transform
     * @param durationTicks interpolation duration
     */
    public void interpolate(MirageTransform transform, int durationTicks) {
        displays.forEach(d -> d.transform(transform).interpolation(durationTicks).startInterpolation(0));
    }

    /**
     * Distributes members evenly along a line.
     *
     * @param start the start point
     * @param end   the end point
     */
    public void distributeLine(class_243 start, class_243 end) {
        if (displays.isEmpty()) return;
        int n = displays.size();
        for (int i = 0; i < n; i++) {
            float t = n == 1 ? 0.5f : (float) i / (n - 1);
            class_243 pos = new class_243(
                    MirageMath.lerp((float) start.field_1352, (float) end.field_1352, t),
                    MirageMath.lerp((float) start.field_1351, (float) end.field_1351, t),
                    MirageMath.lerp((float) start.field_1350, (float) end.field_1350, t)
            );
            MirageDisplay d = displays.get(i);
            d.moveTo(pos);
            offsets.put(d, pos.method_1020(start.method_35590(end, 0.5)));
        }
        this.center = start.method_35590(end, 0.5);
    }

    /**
     * Distributes members evenly around a horizontal circle.
     *
     * @param center the circle center
     * @param radius the radius
     * @param y      the Y coordinate
     */
    public void distributeCircle(class_243 center, double radius, double y) {
        if (displays.isEmpty()) return;
        int n = displays.size();
        for (int i = 0; i < n; i++) {
            double angle = 2 * Math.PI * i / n;
            double x = center.field_1352 + radius * Math.cos(angle);
            double z = center.field_1350 + radius * Math.sin(angle);
            class_243 pos = new class_243(x, y, z);
            MirageDisplay d = displays.get(i);
            d.moveTo(pos);
            offsets.put(d, pos.method_1020(center));
        }
        this.center = center;
    }

    /**
     * Arranges members in a flat grid.
     *
     * @param origin  the top-left corner
     * @param columns the number of columns
     * @param spacing the cell spacing
     */
    public void distributeGrid(class_243 origin, int columns, double spacing) {
        if (displays.isEmpty() || columns <= 0) return;
        int n = displays.size();
        int rows = (int) Math.ceil((double) n / columns);
        class_243 gridCenter = origin.method_1031(
                (columns - 1) * spacing / 2.0,
                -(rows - 1) * spacing / 2.0,
                0
        );
        for (int i = 0; i < n; i++) {
            int row = i / columns;
            int col = i % columns;
            class_243 pos = origin.method_1031(col * spacing, -row * spacing, 0);
            MirageDisplay d = displays.get(i);
            d.moveTo(pos);
            offsets.put(d, pos.method_1020(gridCenter));
        }
        this.center = gridCenter;
    }

    /** Removes all members from the world and clears the group. */
    public void removeAll() {
        displays.forEach(MirageDisplay::remove);
        displays.clear();
        offsets.clear();
    }

    /** Clears the group without removing entities. */
    public void clear() {
        displays.clear();
        offsets.clear();
    }

    /** @return unmodifiable view of members */
    public List<MirageDisplay> getDisplays() {
        return Collections.unmodifiableList(displays);
    }

    /** @return the current center */
    public class_243 getCenter() {
        return center;
    }

    /** @return true if empty */
    public boolean isEmpty() {
        return displays.isEmpty();
    }

    /** @return the member count */
    public int size() {
        return displays.size();
    }
}