package dev.mrkieha.mirage;

import dev.mrkieha.mirage.util.HierarchyMember;
import dev.mrkieha.mirage.util.MirageMath;
import dev.mrkieha.mirage.util.MirageTransform;
import dev.mrkieha.mirage.util.MirageValidation;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4590;
import net.minecraft.class_8104;
import net.minecraft.class_8113;

/**
 * Server-side wrapper around {@link class_8113}.
 *
 * <p>All mutation must happen on the server thread.</p>
 *
 * @since 1.0
 */
public class MirageDisplay implements HierarchyMember {

    private final class_8113 entity;
    private final class_3218 world;
    private final Map<String, Object> userData = new HashMap<>();

    MirageDisplay(class_8113 entity, class_3218 world) {
        this.entity = MirageValidation.requireNonNull(entity, "entity");
        this.world  = MirageValidation.requireNonNull(world, "world");
    }

    /* ---------- Content ---------- */

    /**
     * Sets the block state. No-op if not a block display.
     *
     * @param state the block state
     * @return this
     */
    public MirageDisplay block(class_2680 state) {
        if (entity instanceof class_8113.class_8115 block) {
            block.method_48883(state);
        }
        return this;
    }

    /**
     * @return the block state, or {@code null} if this is not a block display
     */
    public @Nullable class_2680 getBlock() {
        if (entity instanceof class_8113.class_8115 block) {
            return block.method_48884();
        }
        return null;
    }

    /**
     * Sets the item stack. No-op if not an item display.
     *
     * @param stack the item stack
     * @return this
     */
    public MirageDisplay item(class_1799 stack) {
        if (entity instanceof class_8113.class_8122 item) {
            item.method_48897(stack);
        }
        return this;
    }

    /**
     * @return the item stack, or {@link class_1799#field_8037} if this is not an item display
     */
    public class_1799 getItem() {
        if (entity instanceof class_8113.class_8122 item) {
            return item.method_48900();
        }
        return class_1799.field_8037;
    }

    /**
     * Sets the text. No-op if not a text display.
     *
     * @param text the text
     * @return this
     */
    public MirageDisplay text(class_2561 text) {
        if (entity instanceof class_8113.class_8123 txt) {
            txt.method_48911(text);
        }
        return this;
    }

    /**
     * @return the text, or {@code null} if this is not a text display
     */
    public @Nullable class_2561 getText() {
        if (entity instanceof class_8113.class_8123 txt) {
            return txt.method_48915();
        }
        return null;
    }

    /* ---------- Transform ---------- */

    /**
     * Applies a transform.
     *
     * @param transform the transform
     * @return this
     */
    public MirageDisplay transform(MirageTransform transform) {
        entity.method_48849(MirageValidation.requireNonNull(transform, "transform").build());
        return this;
    }

    /**
     * Applies a raw vanilla transform.
     *
     * @param raw the vanilla transform
     * @return this
     */
    public MirageDisplay transform(class_4590 raw) {
        entity.method_48849(raw);
        return this;
    }

    /**
     * Orients the display to face {@code target}.
     *
     * @param target the target position
     * @return this
     */
    public MirageDisplay lookAt(class_243 target) {
        class_243 pos = getPos();
        MirageTransform t = MirageTransform.identity()
                .leftRotation(MirageMath.lookRotation(pos, target));
        return transform(t);
    }

    /** @see #lookAt(class_243) */
    public MirageDisplay faceTowards(class_243 target) {
        return lookAt(target);
    }

    /**
     * Replaces rotation with an absolute X-axis rotation.
     *
     * @param degrees angle in degrees
     * @return this
     */
    public MirageDisplay rotationX(float degrees) {
        return transform(MirageTransform.identity().rotationX(degrees));
    }

    /**
     * Replaces rotation with an absolute Y-axis rotation.
     *
     * @param degrees angle in degrees
     * @return this
     */
    public MirageDisplay rotationY(float degrees) {
        return transform(MirageTransform.identity().rotationY(degrees));
    }

    /**
     * Replaces rotation with an absolute Z-axis rotation.
     *
     * @param degrees angle in degrees
     * @return this
     */
    public MirageDisplay rotationZ(float degrees) {
        return transform(MirageTransform.identity().rotationZ(degrees));
    }

    /**
     * Sets uniform scale.
     *
     * @param uniform the scale factor
     * @return this
     */
    public MirageDisplay scale(float uniform) {
        return transform(MirageTransform.identity().scale(uniform));
    }

    /**
     * Sets non-uniform scale.
     *
     * @param x scale on X
     * @param y scale on Y
     * @param z scale on Z
     * @return this
     */
    public MirageDisplay scale(float x, float y, float z) {
        return transform(MirageTransform.identity().scale(x, y, z));
    }

    /* ---------- Interpolation ---------- */

    /**
     * Sets interpolation duration.
     *
     * @param durationTicks duration in ticks
     * @return this
     */
    public MirageDisplay interpolation(int durationTicks) {
        entity.method_48853(Math.max(0, durationTicks));
        return this;
    }

    /**
     * Sets interpolation start delay.
     *
     * @param delayTicks delay in ticks
     * @return this
     */
    public MirageDisplay startInterpolation(int delayTicks) {
        entity.method_49744(delayTicks);
        return this;
    }

    /**
     * Sets interpolation with zero delay.
     *
     * @param durationTicks duration in ticks
     * @return this
     */
    public MirageDisplay interpolateNow(int durationTicks) {
        entity.method_48853(Math.max(0, durationTicks));
        entity.method_49744(0);
        return this;
    }

    /* ---------- Visual ---------- */

    /**
     * Sets view range multiplier.
     *
     * @param range the multiplier
     * @return this
     */
    public MirageDisplay viewRange(float range) {
        entity.method_48861(range);
        return this;
    }

    /**
     * Sets shadow parameters.
     *
     * @param radius   shadow radius
     * @param strength shadow strength
     * @return this
     */
    public MirageDisplay shadow(float radius, float strength) {
        entity.method_48862(radius);
        entity.method_48872(strength);
        return this;
    }

    /** Disables shadow. */
    public MirageDisplay noShadow() {
        return shadow(0f, 0f);
    }

    /**
     * Sets billboard mode.
     *
     * @param mode the mode
     * @return this
     */
    public MirageDisplay billboard(class_8113.class_8114 mode) {
        entity.method_48847(mode);
        return this;
    }

    /**
     * Sets brightness override.
     *
     * @param block block light, 0–15
     * @param sky   sky light, 0–15
     * @return this
     * @throws IllegalArgumentException if out of range
     */
    public MirageDisplay brightness(int block, int sky) {
        MirageValidation.requireRange(block, 0, 15, "block light");
        MirageValidation.requireRange(sky, 0, 15, "sky light");
        entity.method_48846(new class_8104(block, sky));
        return this;
    }

    /** Sets full brightness (15/15). */
    public MirageDisplay fullBright() {
        return brightness(15, 15);
    }

    /**
     * Sets glow outline color.
     *
     * @param argb ARGB, or -1 to disable
     * @return this
     */
    public MirageDisplay glowColor(int argb) {
        entity.method_48858(argb);
        return this;
    }

    /**
     * Toggles vanilla glowing.
     *
     * @param enabled true to enable
     * @return this
     */
    public MirageDisplay glow(boolean enabled) {
        entity.method_48858(enabled ? 0xFFFFFFFF : -1);
        return this;
    }

    /* ---------- Position ---------- */

    /**
     * Teleports to coordinates.
     *
     * @param x world X
     * @param y world Y
     * @param z world Z
     * @return this
     */
    public MirageDisplay moveTo(double x, double y, double z) {
        entity.method_5814(x, y, z);
        return this;
    }

    /**
     * Teleports to a position.
     *
     * @param pos the position
     * @return this
     */
    public MirageDisplay moveTo(class_243 pos) {
        entity.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
        return this;
    }

    /**
     * Teleports with interpolation.
     *
     * @param pos           the position
     * @param durationTicks interpolation duration
     * @return this
     */
    public MirageDisplay moveTo(class_243 pos, int durationTicks) {
        interpolateNow(durationTicks);
        entity.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
        return this;
    }

    /**
     * Adds an offset to the current position.
     *
     * @param x delta X
     * @param y delta Y
     * @param z delta Z
     * @return this
     */
    public MirageDisplay offset(double x, double y, double z) {
        class_243 pos = getPos();
        return moveTo(pos.field_1352 + x, pos.field_1351 + y, pos.field_1350 + z);
    }

    /** Hides the display. */
    public MirageDisplay hide() {
        return viewRange(0f);
    }

    /** Shows the display. */
    public MirageDisplay show() {
        return viewRange(1.0f);
    }

    /** @return the current position */
    public class_243 getPos() {
        return entity.method_19538();
    }

    /* ---------- Lifecycle ---------- */

    /** Spawns the entity into the world. */
    public MirageDisplay spawn() {
        world.method_8649(entity);
        return this;
    }

    /** Removes the entity from the world. */
    public void remove() {
        entity.method_31472();
    }

    /** @return true if the entity is alive */
    public boolean isAlive() {
        return entity.method_5805();
    }

    /* ---------- Accessors ---------- */

    /** @return the backing entity */
    public class_8113 getEntity() {
        return entity;
    }

    /** @return the world */
    public class_3218 getWorld() {
        return world;
    }

    /** @return the UUID */
    public UUID getUuid() {
        return entity.method_5667();
    }

    /** @return the network entity ID */
    public int getEntityId() {
        return entity.method_5628();
    }

    /* ---------- User data ---------- */

    /**
     * Stores arbitrary data.
     *
     * @param key   the key
     * @param value the value
     * @return this
     */
    public MirageDisplay data(String key, Object value) {
        userData.put(key, value);
        return this;
    }

    /**
     * Retrieves stored data.
     *
     * @param key the key
     * @return the value, or null
     */
    public Object data(String key) {
        return userData.get(key);
    }

    /**
     * Removes stored data.
     *
     * @param key the key
     * @return this
     */
    public MirageDisplay removeData(String key) {
        userData.remove(key);
        return this;
    }

    /* ---------- Clone ---------- */

    /**
     * Copies visual settings from another display.
     * Position and UUID are not copied.
     *
     * @param source the source display
     * @return this
     */
    public MirageDisplay cloneSettingsFrom(MirageDisplay source) {
        MirageValidation.requireNonNull(source, "source");
        class_8113 e = source.getEntity();
        this.transform(e.method_48845(e.method_5841()));
        this.interpolation(e.method_48866());
        this.viewRange(e.method_48869());
        this.shadow(e.method_48870(), e.method_48871());
        this.billboard(e.method_48864());
        int packed = e.method_48865();
        if (packed != -1) {
            this.brightness(class_8104.method_48764(packed).comp_1240(), class_8104.method_48764(packed).comp_1241());
        }
        this.glowColor(e.method_48876());
        return this;
    }
}